export { ThemeToggle as default, ThemeToggle } from './theme-toggle'
